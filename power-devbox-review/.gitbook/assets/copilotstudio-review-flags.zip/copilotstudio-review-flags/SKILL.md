---
name: copilotstudio-review-flags
description: Write custom flags (checks) for the CopilotReview Copilot Studio agent code review app. Use when the user asks to "add a flag", "create a check", "write a custom flag" or rule for Copilot Studio agents, topics, tools, knowledge or agent solutions, or edits "CopilotReview Custom Flags.json". Contains the CopilotReview standard JSON schema (oData), the flag script contract and return format, and rules for refusing flags whose data is not in the standard JSON.
---

# CopilotReview (Copilot Studio) Custom Flags

CopilotReview converts a Copilot Studio solution into a standard JSON. Custom flags are JavaScript function bodies run against it.

## Flag file format

Flags live in `CopilotReview Custom Flags.json` (array). Each entry:

```json
{ "name": "Tool missing description", "code": "<JS function body as a JSON string>", "live": true }
```

- `code` is the **body** of a function; the standard JSON is in scope as `oData`. It must `return` an array (empty = pass).
- `code` must be a valid JSON string: escape `"` as `\"`, newlines as `\n`, backslashes as `\\`.
- `live: true` enables the flag.

## Return format (array of findings)

```js
{
  area: agent.name,          // agent name, or "Solution" for solution-level items
  component: topic.name,     // topic / tool / variable / knowledge / connection ref name
  type: "Orchestration",     // category
  level: "Warning",          // "Error" | "Warning" | "Advice"
  reason: "Short, actionable explanation"
}
```

Existing `type` values (reuse where possible): `MCP permissions`, `Orchestration`, `Housekeeping`, `Maintainability`, `Naming Convention`, `Readability`, `ALM`, `Broken Reference`, `Publish`, `Quality`, `Runtime`, `Skills`, `Security`, `Governance`.

## Standard JSON schema (`oData`)

`oData` is the whole export file. Arrays may be empty; guard optional/rare arrays with `|| []`.

```ts
oData = {
  schemaVersion: string, generator: string, generatedOn: string /* when exported, not modified date */,
  displayName: string, name: string, description: string, version: string, managed: boolean,
  publisher: string, publisherDisplayName: string, publisherPrefix: string, languageCode: string,
  rootComponents: { type: string, typeName: string /* "Process / Flow","AI Model"... */, id: string, schemaName: string, behavior: string }[],
  dependencies: { Required: { type: number, schemaName: string, displayName: string, solution: string, id: string },
                  Dependent: { type: number, displayName: string, id: string },
                  requiredName: string, requiredType: string /* "Connector"... */, requiredSolution: string,
                  dependentName: string, dependentType: string }[],
  connectionReferences: { connectionreferencelogicalname: string, connectionreferencedisplayname: string,
                          connectorid: string, connectionid: string, type: string /* "shared_sharepointonline" */,
                          description: string, isCustom: boolean, customConnectorId: string, guid: string,
                          usedBy: UsedBy[], usedByFlows: string[] /* flow display names */, usedCount: number }[],
  environmentVariables: { displayName: string, name: string, type: number,
                          displayType: "String"|"Number"|"Boolean"|"JSON"|"Data Source"|"Secret",
                          default: string, value: string, hasValue: boolean,
                          connection: string /* for Data Source */, connectionType: string /* "dataset","table" */,
                          description: string, isRequired: boolean, isSecret: boolean, parent: string, guid: string,
                          usedBy: UsedBy[], usedByFlows: string[], usedCount: number }[],
  tables: any[], securityProfile: any[], canvasApps: any[], apps: any[], customControls: any[],
  roles: any[], connectors: any[], componentCollections: any[],   // empty in example; shape unconfirmed
  aiModels: { id: string, name: string, templateId: string, isPrompt: boolean, promptVersion: string,
              prompt: string, modelType: string /* "gpt-41-mini" */, temperature: number,
              inputs: { id: string, name: string, type: string }[], outputFormats: string[], hasCode: boolean,
              configuration: object /* full prompt config incl. modelParameters, settings.recordRetrievalLimit, code */,
              state: string, usedBy: UsedBy[], usedCount: number }[],
  aiPlugins: { name: string, humanName: string, description: string, modelName: string, modelDescription: string,
               pluginType: string, pluginSubtype: string }[],
  componentLinks: { relationship: string, source: string /* component schemaName */, sourceType: string,
                    target: string, targetType: "environmentVariable"|"flow"|"connectionReference"|"aiModel" }[],
  flows: SolutionFlow[],
  agents: Agent[],
  counts: { agents, topics, tools, skills, knowledge, testCases, flows, connectionReferences,
            environmentVariables, aiModels, canvasApps, tables, roles, connectors, dependencies: number }
}

UsedBy = { agent: string, component: string /* schemaName */, componentName: string }

SolutionFlow = {
  displayName: string, name: string, id: string, guid: string, description: string,
  state: "On"|"Off", active: boolean, category: string, parseError: string, isAgentFlow: boolean,
  trigger: { name: string, type: string, kind: string /* "Skills" = agent flow */, connector: string, operationId: string,
             inputs: { name: string, title: string, type: string, description: string, required: boolean }[] },
  outputs: { name: string, title: string, type: string, description: string, required: boolean }[],
  responseCount: number, respondsInBranch: boolean, stepsCount: number, apiActionsCount: number,
  variablesCount: number, exceptionsCount: number, terminateCount: number, connectionCount: number,
  connectors: string[], connectionReferences: { key: string, logicalName: string, api: string, runtimeSource: string /* "embedded" = flow owner's credentials */ }[],
  environmentVariables: string[], usedBy: UsedBy[], agents: string[], usedCount: number
  // NOTE: no action-level detail (use AutoReview for flow internals)
}

Agent = {
  schemaName: string, name: string, guid: string, isPlaceholder: boolean,
  harness: string, harnessKey: string, template: string,
  recognizer: string /* "GenerativeAIRecognizer" */, orchestration: "Generative"|"Classic",
  description: string, instructions: string, instructionsLength: number, responseInstructions: string,
  instructionReferences: { type: string, target: string, property: string, exists: boolean }[],
  model: string /* "GPT41" */, greeting: string,
  conversationStarters: { title: string, text: string }[],
  authentication: { mode: number /* 1 = none/anonymous, 2 = Entra ID integrated, 3 = manual */, modeName: string,
                    trigger: number, triggerName: string },
  accessControlPolicy: string, authorizedSecurityGroups: string,
  language: string, supportedLanguages: string[], customizable: boolean,
  publish: { state: string, provisioningStatus: string, lastSynchronized: string,
             lastPublishStatus: string /* "Succeeded"|"Failed" */, lastPublishDate: string,
             diagnostics: { kind: string, errorCode: string, message: string, referenceType: string,
                            referenceId: string, component: string, actionId: string }[] },
  settings: { generativeOrchestration: boolean, useModelKnowledge: boolean, fileAnalysis: boolean,
              semanticSearch: boolean, contentModeration: "Low"|"Medium"|"High", useLatestModels: boolean,
              webBrowsing: boolean, codeInterpreter: boolean, agentConnectable: any, memory: any,
              telephony: any, redactCreditCard: any, redactSsn: any, publishOnImport: any, channels: any[] },
  configuration: object /* raw BotConfiguration */, gpt: { schemaName, displayName, description, instructions,
                  responseInstructions, conversationStarters, webBrowsing, codeInterpreter, model },
  topics: Topic[], tools: Tool[], skills: Skill[], knowledge: Knowledge[], knowledgeFiles: any[],
  variables: GlobalVariable[], entities: Entity[],
  tests: { sets: any[], cases: any[] },
  settingsComponents: { schemaName: string, name: string, kind: string, description: string }[],
  externalTriggers: any[],
  otherComponents: { schemaName: string, name: string, componentType: number, componentTypeName: string,
                     kind: string, description: string, parseError: string /* YAML failed to parse */ }[],
  flows: { id: string, name: string, inSolution: boolean, usedBy: string[] }[],
  connectionReferences: string[], environmentVariables: string[], aiModels: string[],  // logical names / ids used
  missingReferences: { component: string, componentName: string, type: string, target: string }[],
  counts: { topics, customTopics, systemTopics, inactiveTopics, triggerPhrases, nodes, tools, skills, skillFiles,
            knowledge, knowledgeFiles, variables, entities, testSets, testCases, flows, connectionReferences,
            environmentVariables, aiModels, missingReferences, publishDiagnostics: number }
}

Topic = {
  schemaName: string, name: string, shortName: string, description: string, modelDescription: string,
  active: boolean, isSystem: boolean, isDefault: boolean /* shipped with template */,
  trigger: { kind: string /* "OnRecognizedIntent","OnConversationStart","OnError","OnUnknownIntent","OnRedirect",
                             "OnSelectIntent","OnGeneratedResponse","OnInactivity","OnSystemRedirect" */,
             type: string, displayName: string, phrases: string[], phraseCount: number, condition: string,
             priority: string, includeInOnSelectIntent: boolean },
  startBehavior: string, inputs: any[], outputs: any[],
  nodes: { index: number, id: string, kind: string, displayName: string, depth: number, parent: string,
           branch: string /* condition expression */, detail: string, variable: string, target: string,
           connectionReference: string, operationId: string, knowledgeMode: string, knowledgeSources: string[],
           variablesSet: string[], disabled: boolean }[],
           // node kinds: SendActivity, Question, ConditionGroup, SetVariable, SetTextVariable, ParseValue, EditTable,
           // Foreach, BeginDialog, ReplaceDialog, GotoAction, EndDialog, CancelAllDialogs, EndConversation,
           // ClearAllVariables, InvokeFlowAction, InvokeConnectorAction, InvokeAIBuilderModelAction,
           // SearchAndSummarizeContent, CreateSearchQuery, AdaptiveCardPrompt, LogCustomTelemetryEvent, CSATQuestion
  nodeCount: number, maxDepth: number, messageCount: number, questionCount: number, conditionCount: number,
  redirectCount: number, flowCallCount: number, connectorCallCount: number, aiCallCount: number,
  generativeAnswersCount: number, httpCallCount: number, adaptiveCardCount: number, endsConversation: boolean,
  flows: string[], topicsCalled: string[] /* topic schemaNames */,
  connectorCalls: { connectionReference: string, operationId: string, node: string }[],
  aiModels: string[], knowledgeSources: string[], environmentVariables: string[], systemVariables: string[],
  variables: { name: string /* "Topic.x" or "Global.x" */, scope: "Topic"|"Global", setCount: number, usedCount: number }[],
  parseError: string, hashId: string,
  yaml: string,          // full raw topic YAML (search here for anything not broken out above)
  linkedFlows: string[], linkedConnectionReferences: string[], linkedEnvironmentVariables: string[], linkedAiModels: string[]
}

Tool = {
  schemaName: string, name: string, shortName: string, modelDisplayName: string, modelDescription: string,
  description: string, active: boolean,
  actionKind: string /* example only has "InvokeFlowTaskAction"; others e.g. "InvokeConnectorTaskAction" - verify */,
  toolType: string /* example only has "Agent flow" - verify other values */,
  flowId: string, flowName: string, connectionReference: string, operationId: string,
  connectionMode: string /* "Invoker" (end user) | "Maker" (author) */, connectionProperties: object,
  inputs: { kind: string, name: string, value: string /* Power Fx e.g. "=Env.x" */, description: string }[],
  outputs: { name: string, displayName: string, description: string }[],
  outputMode: string, requiresConfirmation: boolean, confirmationMode: string, responseMode: string,
  mcpToolControl?: { allowsAllTools: boolean, allowedTools: string[], allowedToolCount: number },  // MCP tools only
  environmentVariables: string[], parseError: string, hashId: string, yaml: string,
  linkedFlows: string[], linkedConnectionReferences: string[], linkedEnvironmentVariables: string[], linkedAiModels: string[]
}

Skill = { name: string, hasSkillMd: boolean, files: { isCache: boolean /* __pycache__ */ }[] }  // shape from existing flags

Knowledge = {
  schemaName: string, name: string, description: string, category: string, active: boolean,
  sourceKind: string /* "SharePointSearchSource","PublicSiteSearchSource","DataverseStructuredSearchSource"... */,
  sourceType: string /* "SharePoint","Public website","Dataverse"... */, site: string,
  triggerCondition: string, additionalSearchTerms: string, isLegacySchema: boolean, source: object,
  yaml: string, parseError: string, linkedFlows, linkedConnectionReferences, linkedEnvironmentVariables, linkedAiModels: string[]
}

GlobalVariable = { schemaName: string, name: string /* "Global.x" */, shortName: string, scope: string, description: string,
                   aIVisibility: string, externalInitialization: boolean, outputToExternal: boolean, dataType: string,
                   isUserScope: boolean, declared: boolean, setCount: number, usedCount: number, topics: string[] }

Entity = { schemaName: string, name: string, description: string, kind: string /* "RegexEntity","ClosedListEntity" */,
           pattern: string, itemCount: number, items: any[] }
```

### Useful patterns from existing flags

- Topic/tool YAML: when a field is not broken out, parse `topic.yaml` / `tool.yaml` (e.g. the `fConnectorNodes` helper in the existing "Connections using agent owner credentials" flag extracts `InvokeConnectorAction` nodes with `connectionReference`, `operationId`, `mode` and `inputs`). Reuse it rather than rewriting.
- Skip placeholder agents for agent-level checks: `oData.agents.filter(agent => !agent.isPlaceholder)`.
- Ignore system/default topics when checking maker content: `!topic.isSystem`, `!topic.isDefault`.

## Feasibility check (do this first)

Before writing a flag, map every piece of data the request needs to a field above.

- If all data is available, write the flag.
- If it can only be approximated (e.g. by regex over `yaml`, `instructions` or node `detail`), write it and state the limitation.
- If the data is **not in the standard JSON**, do not write a flag or invent fields. Say it is not possible and why: name the missing data and say the standard JSON does not contain it. Suggest the nearest flag that is possible, if there is one.

Not in the standard JSON (examples): conversation transcripts, analytics (sessions, CSAT scores, resolution/escalation rates), message/credit consumption, test run results (only test case definitions), agent owner/sharing/editors, created/modified dates or modified by, channel publishing per user, DLP policies, user licences, knowledge source content or indexing status, SharePoint permissions, environment variable values per target environment, internal actions of flows (use AutoReview for those).

## Workflow

1. Run the feasibility check.
2. Read the existing flags file (if in the workspace) to match style and avoid duplicates. Existing flags: MCP connectors allowing all tools, MCP connectors allowing more than five tools, Topic missing description (generative orchestration), Inactive topics shipped, Complex topic, Variable naming convention, Unused global variables, Tool missing description, Duplicate tool names, Hard coded ids in tool inputs, Broken references, Last publish failed, No evaluations, Instructions length, Unused connection references, Unused environment variables, Agent flows turned off, Knowledge using default description, Skill package hygiene, Authentication, Hard coded URLs, Unused connections and data sources, Data sources not using environment variables, Code not formatted, Unused topic variables, Model not approved, Uploaded files as knowledge, Connections using agent owner credentials.
3. Write the code using the conventions: `let aErrors=[];`, Hungarian-style names (`aList`, `sName`, `oItem`, `iMax`, `bFlag`, `fHelper`), configurable values as constants at the top, guard optional arrays with `|| []`, `return aErrors`.
4. Append the entry to the flags JSON file (keep valid JSON), or output the entry if no file is available.
5. Test it against an example export if one exists (e.g. `*-data.json`). On Windows PowerShell pipe a here-string to node:

```powershell
@'
const fs = require('fs');
const aFlags = JSON.parse(fs.readFileSync('CopilotReview Custom Flags.json', 'utf8').replace(/^\uFEFF/, ''));
const oData = JSON.parse(fs.readFileSync('Kevin_3_0_2_1-data.json', 'utf8').replace(/^\uFEFF/, ''));
const oFlag = aFlags.find(f => f.name == 'FLAG NAME');
console.log(new Function('oData', oFlag.code)(oData));
'@ | node
```
