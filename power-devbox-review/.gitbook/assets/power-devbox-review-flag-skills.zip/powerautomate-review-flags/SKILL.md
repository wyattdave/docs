---
name: powerautomate-review-flags
description: Write custom flags (checks) for the AutoReview Power Automate code review app. Use when the user asks to "add a flag", "create a check", "write a custom flag" or rule for Power Automate flows/solutions, or edits "AutoReview Custom Flags.json". Contains the AutoReview standard JSON schema (oData), the flag script contract and return format, and rules for refusing flags whose data is not in the standard JSON.
---

# AutoReview (Power Automate) Custom Flags

AutoReview converts a Power Automate solution into a standard JSON. Custom flags are JavaScript function bodies run against it.

## Flag file format

Flags live in `AutoReview Custom Flags.json` (array). Each entry:

```json
{ "name": "Unused Variables", "code": "<JS function body as a JSON string>", "live": true }
```

- `code` is the **body** of a function; the standard JSON is in scope as `oData`. It must `return` an array (empty = pass).
- `code` must be a valid JSON string: escape `"` as `\"`, newlines as `\n`, backslashes as `\\` (regex `\d` becomes `\\d`).
- `live: true` enables the flag.
- `console.log` is allowed but should not be left in new flags.

## Return format (array of findings)

```js
{
  area: flow.review.name,      // flow name, or "Solution" for solution-level items
  component: item.name,        // action / variable / connection ref / env var name
  type: "Wasted API Calls",    // category
  level: "Error",              // "Error" | "Warning" | "Debug"
  reason: "Unused variable"    // short, actionable explanation
}
```

Existing `type` values (reuse where possible): `Naming Convention`, `Inconsistent Behaviour`, `Impacts Readability`, `Wasted API Calls`, `Exception Handling`, `Action Settings`, `ALM`.

## Standard JSON schema (`oData`)

The export file is `[{ name, data }]`; flags receive `oData = data`.

```ts
oData = {
  flows: Flow[],
  // Solution-level arrays: used by existing flags, may be absent from some exports -> always guard with `|| []`
  connectionReferences?: { connectionreferencedisplayname: string, connectionreferencelogicalname: string,
                           connectorid: string /* "/providers/Microsoft.PowerApps/apis/shared_sharepointonline" */ }[],
  environmentVariables?: { displayName: string, name: string /* schema name */, type: number,
                           displayType: string /* "String"|"Number"|"JSON"|"Data Source"|"Secret"|"Boolean" */ }[],
                           // type: 100000000 String, 100000001 Number, 100000002 Boolean, 100000003 JSON, 100000004 Data Source, 100000005 Secret
  dependencies?: { Required: { type: number|string, displayName: string, id: string, "id.connectionreferencelogicalname"?: string },
                   Dependent: { displayName: string } }[]   // missing solution dependencies
}

Flow = {
  displayName: string, id: string /* guid */, guid: string /* "Solution|guid" */,
  review: {
    name: string, uniqueName: string, id: string,
    trigger: {
      name: string, type: string /* "Request","Recurrence","OpenApiConnection","OpenApiConnectionWebhook","Skills"... */,
      data: string /* connection info, e.g. contains "shared_sharepointonline" */,
      manual: string, parameters: string /* YAML-like text */, config: string,
      expression: string /* trigger conditions */, inputs: string, recurrence: string,
      icon: string, connection: string, premium: "Standard"|"Premium", hashId: string
    },
    premium: boolean,
    connectionCount: number, stepsCount: number, apiActionsCount: number,
    variablesCount: number, exceptionsCount: number,
    variableArray: { name: string, type: "string"|"integer"|"float"|"boolean"|"array"|"object",
                     value: string /* initial value */, setCount: number, usedCount: number }[],
    actionArray: Action[],      // every action in the flow (flat list)
    exceptionArray: Action[],   // actions that run after a failure (exception handling)
    connectionArray: { connection: string /* "shared_sharepointonline" or "shared_x-1" */, referenceName: string,
                       type: string, runAs: string /* "invoker" | "" */, usedCount: number,
                       connectionReference: string /* display name */ }[]
  }
}

Action = {
  name: string,                 // action name with spaces as "_" e.g. "Get_items"
  step: string,                 // operation id e.g. "GetItems","ListRecords","SendEmailV2","Compose","Scope","If","HttpRequest"
  type: string,                 // "Scope","If","Foreach","Until","Switch","OpenApiConnection","Query"(Filter array),"Select","Compose",
                                // "InitializeVariable","SetVariable","AppendToStringVariable","ParseJson","Table","Response","Terminate","Wait","Http"...
  id: string, index: number /* 1-based, unique within flow */, hashId: string,
  tier: "Standard"|"Premium",
  container: boolean,           // Scope / If / Foreach / Until / Switch
  connection: string,           // e.g. "shared_sharepointonline", "" for built-in
  connectorName: string,        // friendly connector name e.g. "SharePoint"
  icon: string,
  environmentVariables: string, // "null" or JSON string array: ["@parameters('Display Name (schema_name)"]
  environmentVariablesCount: number,
  notes: string,                // action note/comment
  runAfter: string,             // "root:Succeeded" | "Main:TimedOut | Failed" | "Prev_action:Succeeded"
  runAfterMode: string,
  exception: "Exception"|"Non-Exception",
  detail: string,               // action inputs as YAML-like text, HTML-encoded (&quot; &#39; &amp; &lt; &gt;)
  secure: "true"|"false",       // secure inputs/outputs
  retry: string, timeout: string,
  list: { filter: string /* $filter / query */, pagination: "" | number /* threshold */ },
  position: string,             // "|PreviousSibling|" or "|trigger|" or "|ParentName|" if first in container
  positionInfo: "Internal"|"",  // "Internal" = first action inside its container
  parent: string,               // parent container name or "root"
  branch: "Yes"|"No"|"",        // branch within an If parent
  positionIndex: string, positionType: string,
  nested: string                // pipe list of ancestor container indexes, nearest first e.g. "6|4|1"; "" at root
}
```

### Useful patterns from existing flags

```js
const decode = s => String(s ?? "").replace(/&quot;/g, "\"").replace(/&#39;/g, "'").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
const firstChild = cont => aActions.find(a => a.parent == cont.name && (a.positionInfo == "Internal" || a.position == "|" + cont.name + "|"));
const nextSibling = cur => aActions.find(a => a.parent == cur.parent && a.position == "|" + cur.name + "|");
const ancestors = a => String(a.nested || "").split("|").filter(Boolean).map(i => aActions.find(x => String(x.index) == i));
// Find references to an action's output in other actions
const usesAction = (a, name) => [`outputs('${name}')`, `body('${name}')`].some(r => decode(a.detail).replace(/\s+/g, "").includes(r));
```

Main/Exception scopes are identified by name: `"Main"`, `"Exception"`/`"Exceptions"`.

## Feasibility check (do this first)

Before writing a flag, map every piece of data the request needs to a field above.

- If all data is available, write the flag.
- If it can only be approximated (e.g. by regex over `detail`, `trigger.parameters` or `expression`), write it and state the limitation.
- If the data is **not in the standard JSON**, do not write a flag or invent fields. Say it is not possible and why: name the missing data and say the standard JSON does not contain it. Suggest the nearest flag that is possible, if there is one.

Not in the standard JSON (examples): run history, success/failure rates, run duration, flow owner/co-owners/sharing, created/modified dates or modified by, flow on/off state, flow description, licensing/plan of users, DLP policies, actual connection credentials/accounts, environment variable current values, runtime data values, API request counts per run.

## Workflow

1. Run the feasibility check.
2. Read the existing flags file (if in the workspace) to match style and avoid duplicates. Existing flags: Connection Ref Name, Environment Var Name, Duplicate connection references, Variable naming, Unused Variables, Composes, Main scope, Exception scope, Pagination, Filter Query, Hard coded email, Variable never set, Variable in a condition, Exception run link, Error message, Nested conditions, Missing dependencies, Data source environment variables, Condition after trigger, Loops within loops, Condition in loop, Hard coded URLs and IDs.
3. Write the code using the conventions: `let aErrors = [];`, Hungarian-style names (`aList`, `sName`, `oItem`, `iCount`, `bFlag`), configurable values as constants at the top, `return aErrors;`. Guard optional arrays with `|| []`.
4. Append the entry to the flags JSON file (keep valid JSON), or output the entry if no file is available.
5. Test it against an example export if one exists (e.g. `auto-data.json`). On Windows PowerShell pipe a here-string to node:

```powershell
@'
const fs = require('fs');
const aFlags = JSON.parse(fs.readFileSync('AutoReview Custom Flags.json', 'utf8').replace(/^\uFEFF/, ''));
const oData = JSON.parse(fs.readFileSync('auto-data.json', 'utf8').replace(/^\uFEFF/, ''))[0].data;
const oFlag = aFlags.find(f => f.name == 'FLAG NAME');
console.log(new Function('oData', oFlag.code)(oData));
'@ | node
```
