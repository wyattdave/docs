---
name: powerapps-review-flags
description: Write custom flags (checks) for the Power Apps canvas app code review app. Use when the user asks to "add a flag", "create a check", "write a custom flag" or rule for Power Apps / canvas apps, or edits the app "Custom Flags.json". Contains the app review standard JSON schema (oData), the flag script contract and return format, and rules for refusing flags whose data is not in the standard JSON.
---

# Power Apps Review Custom Flags

The app review tool converts a canvas app solution into a standard JSON. Custom flags are JavaScript function bodies run against it.

## Flag file format

Flags live in `Custom Flags.json` (array). Each entry:

```json
{ "name": "Missing IfError", "live": true, "code": "<JS function body as a JSON string>" }
```

- `code` is the **body** of a function; the standard JSON is in scope as `oData`. It must `return` **one result object** (not an array).
- `code` must be a valid JSON string: escape `"` as `\"`, newlines as `\n`, backslashes as `\\` (regex `\s` becomes `\\s`).
- `live: true` enables the flag.

## Return format (single pass/fail object)

```js
return {
  Name: "IfError Not Used",                   // title shown in the report
  Pass: aFail.length == 0,                    // true = check passed
  Level: "Medium",                            // "Low" | "Medium" | "High" | "Warning"
  How: "How to fix" + (aFail.length ? ". Found: " + aFail.join(", ") : ""),  // list offending items here
  Why: "Why it matters",
  Type: "app",
  Category: "performance"                     // "deployment" | "security" | "performance" | "user experience" | "maintainability"
};
```

One flag = one result. Report the offending items by appending `". Found: ..."` to `How`.

## Standard JSON schema (`oData`)

`oData` is the whole export file.

```ts
oData = {
  AppConfig: { Name: string, ScreenCount: number, ComponentCount: number, VarCount: number, ConnectionCount: number,
               AppId: string, AppType: string /* "DesktopOrTablet" | "Phone" */, AppDescript: string /* app description */,
               AppAPILimit: number /* data row limit */, Version: string /* app version */, PCF: boolean /* code components enabled */,
               AppError: number /* app checker error count */, AppKey: string /* App Insights key or "No Instrument Key" */ },
  Solution: { Name: string, UniqueName: string, Version: string, Managed: number /* 0|1 */, Publisher: string },
  Code: string,          // ALL app code as HTML (see "Code format"); includes App.OnStart and every screen/control formula
  Screens: { Screen: string, CentCount: number,
             Rules: { Property: string /* "OnVisible","Fill","Width"... */, Category: "Design"|"Behavior",
                      InvariantScript: string /* Power Fx */, RuleProviderType: "Unknown"|"User" }[] }[],
  ComponentTotals: { Component: string /* control type */, Count: number }[],
  Components: {          // ONE ROW PER CONTROL PROPERTY (a control appears many times)
    Screen: string, Name: string /* control name */,
    Type: string,        // "label","button","icon","gallery","galleryTemplate","groupContainer","rectangle","image","text","timer",
                         // "PowerApps_CoreControls_ButtonCanvas" (modern), 32-hex-char id = custom component instance
    Property: string,    // "X","Y","Width","Height","Fill","Color","Text","OnSelect","DisplayMode","Visible","AccessibleLabel","TabIndex"...
    Script: string       // Power Fx formula (plain text)
  }[],
  ComponentsYAML: { Component: string, YAML: string /* pa.yaml for the control incl. Control: "Classic/Icon@2.5.0" */ }[],
  Variables: {
    Local:  { Variable: string, Screen: string, Set: number, Used: number }[],   // UpdateContext / context vars
    Global: { Variable: string, Type: "Global", Set: number, Used: number }[],   // Set()
    Collections: { Variable: string, Set: number, Used: number }[],
    Formulas: string     // App.Formulas (named formulas) as HTML (<br>, &nbsp;)
  },
  Connections: { Name: string, ApiId: string /* e.g. "/environment_39a902ba" */ }[],
  DataSources: { Name: string, DatasetName: string /* site URL or "default.cds" for Dataverse */,
                 EnvironmentVar: "true"|"false"|"n/a" }[],
  Flows: { Name: string, Flow: string /* guid */ }[],             // flows called by the app
  Tests: { Suites: { SuiteTrigger: string, Action: string }[],
           Tests: { Suite: string, Test: string, TestDescription: string, Action: string }[] },
  MissingDependencies: { Name: string, Type: number, NameReq: string, ParentId: string }[],
  EnvironmentVariables: { Name: string, Description: string, API: string, DataType: string /* e.g. "String","Number","JSON","Secret" */,
                          Type: number /* 100000000 String, ...01 Number, ...02 Boolean, ...03 JSON, ...04 Data Source, ...05 Secret */ }[],
  ConnectionReferences: { Name: string, Id: string /* logical name */, Type: string /* connector path */ }[],
  SolutionFlows: { Name: string, Id: string, SubProcess: number }[],
  Tables: { Name: string, Id: string, Description: string }[]
}
```

### Code format

`oData.Code` is HTML: sections start with `<span class="purple-border"><b>Screen - Control</b></span>`, property names in `<b>..</b>`, line breaks `<br>`, indents `&nbsp;`. Simple regex checks may run against it directly (e.g. `/IfError/.test(oData.Code)`). For accurate per-location checks use the standard source preamble below, which builds `aSrc = [{loc, code}]` of plain Power Fx from Components, Screen rules, App.Formulas and App sections:

```js
const dec=s=>String(s||'').replace(/<br\s*\/?>/gi,'\n').replace(/<\/?b>|<span[^>]*>|<\/span>/gi,'').replace(/&nbsp;/g,' ');
// remove comments; strings kept if bStr else emptied to ""
const clean=(s,bStr)=>String(s).replace(/"(?:[^"]|"")*"|\/\/[^\n]*|\/\*[\s\S]*?\*\//g,m=>m.charAt(0)=='"'?(bStr?m:'""'):'');
const aSrc=[];
(oData.Components||[]).forEach(c=>aSrc.push({loc:c.Name+'.'+c.Property,code:String(c.Script||'')}));
(oData.Screens||[]).forEach(s=>(s.Rules||[]).forEach(r=>aSrc.push({loc:s.Screen+'.'+r.Property,code:String(r.InvariantScript||'')})));
aSrc.push({loc:'App.Formulas',code:dec((oData.Variables||{}).Formulas)});
String(oData.Code||'').split('<span class="purple-border"><b>').forEach(s=>{if(s.indexOf('Application')==0)aSrc.push({loc:'App',code:dec(s.replace(/^[\s\S]*?<\/b><\/span>/,''))})});
const sAll=aSrc.map(o=>clean(o.code)).join('\n');
// whole-word reference to a name (handles 'quoted names')
const esc=s=>String(s).replace(/[.*+?^${}()|[\]\\]/g,m=>'\\'+m);
const ref=n=>new RegExp("'"+esc(n)+"'|(?<![A-Za-z0-9_.])"+esc(n)+'(?![A-Za-z0-9_])');
```

Remember to double the backslashes when placing this inside the JSON `code` string.

Control-level checks: group `Components` by `Name` (and `Screen`) and look up the property you need, e.g. `oData.Components.filter(c => c.Name == sName && c.Property == "AccessibleLabel")`. A property not listed for a control is using its default value.

## Feasibility check (do this first)

Before writing a flag, map every piece of data the request needs to a field above.

- If all data is available, write the flag.
- If it can only be approximated (e.g. regex over Power Fx), write it and state the limitation.
- If the data is **not in the standard JSON**, do not write a flag or invent fields. Say it is not possible and why: name the missing data and say the standard JSON does not contain it. Suggest the nearest flag that is possible, if there is one.

Not in the standard JSON (examples): app usage/analytics, number of users, sessions or load times measured at runtime, app owner/co-owners/sharing, created/modified dates or modified by, published version history, user licences, DLP policies, connection credentials, environment variable current values, data source row counts/schema columns, rendered visuals (screenshots), media file sizes, Monitor/App Insights telemetry.

## Workflow

1. Run the feasibility check.
2. Read the existing flags file (if in the workspace) to match style and avoid duplicates. Existing flags: Missing Dependencies, No Environment Variables, Too Many Connections, Too Many Components, Missing Concurrent, Missing IfError, Double Filter Used, Hard Coded URLs, Unused Connections And Data Sources, Data Sources Not Using Environment Variables, Code Not Formatted, Unused Variables, Unused Collections, Variable Naming Convention, Collection Naming Convention, Component Naming Convention, ShowColumns/DropColumns Not Used.
3. Write the code using the conventions: Hungarian-style names (`aFail`, `sPrefix`, `oCfg`, `iMax`, `bPass`), configurable values as constants at the top, guard arrays with `|| []`, return the single result object.
4. Append the entry to the flags JSON file (keep valid JSON), or output the entry if no file is available.
5. Test it against an example export if one exists (e.g. `app example.json`). On Windows PowerShell pipe a here-string to node:

```powershell
@'
const fs = require('fs');
const aFlags = JSON.parse(fs.readFileSync('Custom Flags.json', 'utf8').replace(/^\uFEFF/, ''));
const oData = JSON.parse(fs.readFileSync('app example.json', 'utf8').replace(/^\uFEFF/, ''));
const oFlag = aFlags.find(f => f.name == 'FLAG NAME');
console.log(new Function('oData', oFlag.code)(oData));
'@ | node
```
